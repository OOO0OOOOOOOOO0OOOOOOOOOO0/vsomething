const CACHE = 'parcel-noir-v21';
const CORE = ['./', './index.html', './manifest.json', './images/180x180.png', './images/192x192.png', './images/512x512.png', './images/maskable-192.png', './images/maskable-512.png',
  './images/carriers/aliexpress.png', './images/carriers/amazon.png', './images/carriers/austrian_post.png', './images/carriers/boxtal.png', './images/carriers/brt.png', './images/carriers/cainiao.png', './images/carriers/canada_post.png', './images/carriers/china_post.png', './images/carriers/chronopost.png', './images/carriers/colisprive.png', './images/carriers/correos.png', './images/carriers/ctt.png', './images/carriers/dhl.png', './images/carriers/dpd.png', './images/carriers/evri.png', './images/carriers/fedex.png', './images/carriers/gls.png', './images/carriers/inpost.png', './images/carriers/japan_post.png', './images/carriers/laposte.png', './images/carriers/mondial.png', './images/carriers/postnl.png', './images/carriers/postnord.png', './images/carriers/royal_mail.png', './images/carriers/sf_express.png', './images/carriers/swiss_post.png', './images/carriers/ups.png', './images/carriers/usps.png', './images/carriers/yunexpress.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  // On ne touche qu'aux GET de notre propre origine (les appels API passent directement)
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;

  // Pages : réseau d'abord, cache si hors ligne
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put('./index.html', copy));
        return res;
      }).catch(() => caches.match('./index.html'))
    );
    return;
  }

  // Manifest : réseau d'abord (PWABuilder et l'installation voient toujours la dernière version)
  if (url.pathname.endsWith('/manifest.json')) {
    e.respondWith(
      fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => caches.match(req))
    );
    return;
  }

  // Images : cache d'abord, puis réseau (et mise en cache)
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
      return res;
    }))
  );
});
